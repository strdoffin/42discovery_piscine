i=1
v=$#
if [ $v -ne 0 ];then

	for i in $@
	do
  	  mkdir "ex$i"
  	  i=i+1
	done
else
	echo no arguments supplied
fi
